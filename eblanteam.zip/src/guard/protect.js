module.exports = async function protect(req, res, next) {
    
}